# Sotoboats Invoicing v1 — YDP Pilot

This is the first live-business pilot of the **Your Dispatch Partner invoicing engine**.

It is configured for:

- **Trading name:** Sotoboats
- **Legal entity:** Marbella Sailing School S.L.
- **Company ID:** ESB93733012
- **Currency:** EUR
- **Country:** Spain
- **Current invoice sequence:** starts at **0001575**, following the supplied invoice #0001574
- **VAT:** per-line 0%, 10% or 21%
- **Default payment terms:** 5 days
- **Deposit rule:** 25% when the service start date is more than 30 days away; otherwise full payment is due
- **Languages:** English, Spanish or bilingual
- **Bank transfer:** supported
- **PDF:** generated from issued invoices

## What v1 can do

- Secure admin login
- Company/invoice settings
- Customer records
- Optional customer tax ID and passport/ID reference
- Create draft invoices
- Edit drafts
- English + Spanish line descriptions
- Per-line VAT rate
- Automatic deposit/full-payment calculation
- Issue invoices sequentially
- Lock issued invoices against editing
- Download an issued invoice as PDF
- Record bank/cash/external-card payments
- Part-paid and paid statuses
- Audit trail

## What is deliberately not active yet

- Stripe Connect / online Pay Now
- Email delivery
- Credit-note UI
- VERI*FACTU submission
- Spanish B2B electronic invoice transmission
- Booking-system integration

The database structure keeps issued invoices immutable so later compliance and payment work can be added without replacing the invoice core.

## Deploy to Render

I recommend a **new Web Service** for the pilot rather than changing the working Sotoboats public website or YDP-HQ.

1. Create a new GitHub repository, for example `sotoboats-invoicing`.
2. Upload all files from this package.
3. Create a Render PostgreSQL database.
4. Create a Render Web Service from the new repo.
5. Build command: `npm install`
6. Start command: `npm start`
7. Add these environment variables in Render:
   - `DATABASE_URL` = the Render Postgres internal URL
   - `NODE_ENV` = `production`
   - `SESSION_SECRET` = a long random secret
   - `ADMIN_EMAIL` = Dave/Rachel login email
   - `ADMIN_PASSWORD` = a strong password
8. Run the schema once. The easiest first deployment is Render Shell:
   `npm run db:init`
9. Open the service URL and sign in.

## First real-world test

Create a test customer and reproduce the supplied €900 invoice as a **draft**:

- Food / Board / Cleaning: €440.00 net at 10% VAT
- Tuition: €343.80 net at 21% VAT
- Net subtotal: €783.80
- VAT: €116.20
- Invoice total: €900.00

Do **not** press Issue until Dave confirms the numbering and company/settings screen. Once Issue is pressed, the draft is locked and receives the next number.

## Important numbering note

The supplied existing invoice is **#0001574**. This build therefore seeds the next number as **0001575** and keeps the prefix blank. That preserves the existing visible sequence rather than unexpectedly switching Dave to `STB-1575`.
